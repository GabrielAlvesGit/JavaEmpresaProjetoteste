package br.edu.ifsp.xyz.teste;

public class CategoriadoProdutoTeste {

}
