package br.edu.ifsp.xyz.comissao;

public class Empresa {
	
}
